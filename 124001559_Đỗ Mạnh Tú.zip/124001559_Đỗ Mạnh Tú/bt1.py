"""Display webcam frames in grayscale.

Install the dependency once in a terminal:
python -m pip install opencv-python
"""

try:
    import cv2
except ModuleNotFoundError as error:
    raise SystemExit(
        "OpenCV is missing. Run: python -m pip install opencv-python"
    ) from error


def main():
    camera = cv2.VideoCapture(0)
    if not camera.isOpened():
        camera.release()
        raise SystemExit("Could not open the camera. Check its connection and permissions.")

    try:
        while True:
            success, frame = camera.read()
            if not success:
                print("Could not read a frame from the camera.")
                break

            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            cv2.imshow("Webcam - Grayscale", gray_frame)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
