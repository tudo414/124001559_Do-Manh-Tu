"""Play a video and rotate it with the A and D keys."""

import tkinter as tk
from tkinter import filedialog

try:
	import cv2
except ModuleNotFoundError as error:
	raise SystemExit(
		"OpenCV is missing. Run: python -m pip install opencv-python"
	) from error


def main():
	root = tk.Tk()
	root.withdraw()
	screen_width = root.winfo_screenwidth()
	screen_height = root.winfo_screenheight()
	video_path = filedialog.askopenfilename(
		title="Select a video",
		filetypes=[
			("Video files", "*.mp4 *.avi *.mov *.mkv *.wmv"),
			("All files", "*.*"),
		],
	)
	root.destroy()

	if not video_path:
		print("No video selected. Program stopped.")
		return

	video = cv2.VideoCapture(video_path)
	if not video.isOpened():
		video.release()
		raise SystemExit("Could not open the selected video.")

	fps = video.get(cv2.CAP_PROP_FPS)
	frame_delay = max(1, round(1000 / fps)) if fps > 0 else 33
	rotation = 0
	max_display_width = max(1, int(screen_width * 0.9))
	max_display_height = max(1, int(screen_height * 0.85))
	window_name = "Video - A: rotate left, D: rotate right, Q: quit"
	last_window_size = None
	cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

	try:
		while True:
			success, frame = video.read()
			if not success:
				break

			if rotation == 90:
				frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
			elif rotation == 180:
				frame = cv2.rotate(frame, cv2.ROTATE_180)
			elif rotation == 270:
				frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)

			frame_height, frame_width = frame.shape[:2]
			scale = min(
				max_display_width / frame_width,
				max_display_height / frame_height,
				1.0,
			)
			if scale < 1.0:
				display_size = (
					max(1, int(frame_width * scale)),
					max(1, int(frame_height * scale)),
				)
				frame = cv2.resize(frame, display_size, interpolation=cv2.INTER_AREA)
			else:
				display_size = (frame_width, frame_height)

			if display_size != last_window_size:
				cv2.resizeWindow(window_name, *display_size)
				window_x = max(0, (screen_width - display_size[0]) // 2)
				window_y = max(0, (screen_height - display_size[1]) // 2)
				cv2.moveWindow(window_name, window_x, window_y)
				last_window_size = display_size

			cv2.imshow(window_name, frame)
			key = cv2.waitKey(frame_delay) & 0xFF

			if key in (ord("a"), ord("A")):
				rotation = (rotation - 90) % 360
			elif key in (ord("d"), ord("D")):
				rotation = (rotation + 90) % 360
			elif key in (ord("q"), ord("Q"), 27):
				break
	finally:
		video.release()
		cv2.destroyAllWindows()


if __name__ == "__main__":
	main()
