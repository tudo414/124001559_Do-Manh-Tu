"""Detect faces from a webcam and save them when S is pressed."""

from pathlib import Path

try:
	import cv2
except ModuleNotFoundError as error:
	raise SystemExit(
		"OpenCV is missing. Run: python -m pip install opencv-python"
	) from error


def main():
	model_path = Path(__file__).resolve().parent / "face_detection_yunet_2026may.onnx"
	if not model_path.is_file():
		raise SystemExit(f"Face detection model not found: {model_path}")

	face_detector = cv2.FaceDetectorYN.create(
		"onnx",
		model_path.read_bytes(),
		b"",
		(640, 480),
		0.8,
		0.3,
		5000,
	)

	camera = cv2.VideoCapture(0)
	if not camera.isOpened():
		camera.release()
		raise SystemExit("Could not open the webcam. Check its connection and permissions.")

	output_dir = Path(__file__).resolve().parent
	next_file_index = 0
	while (output_dir / f"{next_file_index}.png").exists():
		next_file_index += 1

	window_name = "Face Detection - S: save faces, Q: quit"
	try:
		while True:
			success, frame = camera.read()
			if not success:
				print("Could not read a frame from the webcam.")
				break

			color_frame = frame.copy()
			frame_height, frame_width = frame.shape[:2]
			face_detector.setInputSize((frame_width, frame_height))
			_, faces = face_detector.detect(frame)
			face_count = 0 if faces is None else len(faces)

			for face in faces if faces is not None else ():
				x, y, width, height = (int(value) for value in face[:4])
				cv2.rectangle(
					frame, (x, y), (x + width, y + height), (0, 255, 0), 2
				)

			cv2.putText(
				frame,
				f"Faces: {face_count} | S: save | Q: quit",
				(10, 30),
				cv2.FONT_HERSHEY_SIMPLEX,
				0.7,
				(0, 255, 0),
				2,
			)
			cv2.imshow(window_name, frame)
			key = cv2.waitKey(1) & 0xFF

			if key in (ord("s"), ord("S")):
				if face_count == 0:
					print("No faces detected to save.")
				for face in faces if faces is not None else ():
					x, y, width, height = (int(value) for value in face[:4])
					x0 = max(0, x)
					y0 = max(0, y)
					x1 = min(frame_width, x + width)
					y1 = min(frame_height, y + height)
					face_image = color_frame[y0:y1, x0:x1]
					output_path = output_dir / f"{next_file_index}.png"
					if cv2.imwrite(str(output_path), face_image):
						print(f"Saved: {output_path}")
						next_file_index += 1
					else:
						print(f"Could not save: {output_path}")
			elif key in (ord("q"), ord("Q"), 27):
				break
	finally:
		camera.release()
		cv2.destroyAllWindows()


if __name__ == "__main__":
	main()

