"""Count balls in an image using OpenCV."""

import tkinter as tk
from pathlib import Path
from tkinter import filedialog

import numpy as np

try:
	import cv2
except ModuleNotFoundError as error:
	raise SystemExit(
		"OpenCV is missing. Run: python -m pip install opencv-python"
	) from error


def find_balls(image):
	hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
	saturation = hsv[:, :, 1]
	value = hsv[:, :, 2]

	open_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
	min_area = max(50, int(image.shape[0] * image.shape[1] * 0.00015))

	def collect_balls(mask):
		contours, _ = cv2.findContours(
			mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
		)
		candidates = []
		for contour in contours:
			area = cv2.contourArea(contour)
			if area < min_area:
				continue

			x, y, width, height = cv2.boundingRect(contour)
			aspect_ratio = width / max(1, height)
			if 0.35 <= aspect_ratio <= 1.5:
				candidates.append((contour, x, y, width, height))
		return candidates

	color_mask = cv2.threshold(saturation, 40, 255, cv2.THRESH_BINARY)[1]
	color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_OPEN, open_kernel)
	colored_balls = collect_balls(color_mask)

	dark_mask = cv2.threshold(value, 75, 255, cv2.THRESH_BINARY_INV)[1]
	for _, x, y, width, height in colored_balls:
		dark_mask[y:y + height, x:x + width] = 0
	dark_mask = cv2.morphologyEx(dark_mask, cv2.MORPH_OPEN, open_kernel)
	dark_balls = collect_balls(dark_mask)

	balls = colored_balls + dark_balls
	return sorted(balls, key=lambda ball: (ball[2], ball[1]))


def label_balls(image, balls):
	result = image.copy()
	font = cv2.FONT_HERSHEY_SIMPLEX

	for number, (_, x, y, width, height) in enumerate(balls, start=1):
		font_scale = max(0.5, min(1.0, height / 90))
		thickness = max(1, round(font_scale * 2))
		label = str(number)
		(label_width, label_height), _ = cv2.getTextSize(
			label, font, font_scale, thickness
		)
		position = (
			x + (width - label_width) // 2,
			y + (height + label_height) // 2,
		)
		cv2.putText(
			result,
			label,
			position,
			font,
			font_scale,
			(0, 0, 0),
			thickness + 3,
			cv2.LINE_AA,
		)
		cv2.putText(
			result,
			label,
			position,
			font,
			font_scale,
			(255, 255, 255),
			thickness,
			cv2.LINE_AA,
		)

	header = f"Balls: {len(balls)}"
	header_scale = max(0.6, min(1.0, image.shape[1] / 700))
	header_position = (12, max(28, int(35 * header_scale)))
	cv2.putText(
		result,
		header,
		header_position,
		font,
		header_scale,
		(0, 0, 0),
		4,
		cv2.LINE_AA,
	)
	cv2.putText(
		result,
		header,
		header_position,
		font,
		header_scale,
		(255, 255, 255),
		2,
		cv2.LINE_AA,
	)
	return result


def main():
	root = tk.Tk()
	root.withdraw()
	image_path = filedialog.askopenfilename(
		title="Select an image containing balls",
		filetypes=[
			("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"),
			("All files", "*.*"),
		],
	)
	root.destroy()

	if not image_path:
		print("No image selected. Program stopped.")
		return

	image_bytes = np.frombuffer(Path(image_path).read_bytes(), dtype=np.uint8)
	image = cv2.imdecode(image_bytes, cv2.IMREAD_COLOR)
	if image is None:
		raise SystemExit("OpenCV could not read the selected image.")

	balls = find_balls(image)
	print(f"Số quả bóng trong ảnh: {len(balls)}")
	result = label_balls(image, balls)
	cv2.imshow("Counted balls", result)
	print("Press any key in the image window to close it.")
	cv2.waitKey(0)
	cv2.destroyAllWindows()


if __name__ == "__main__":
	main()