"""Automatically find a license plate and save each character crop."""

import tkinter as tk
from pathlib import Path
from tkinter import filedialog

import cv2
import numpy as np


def find_plate_region(image):
	gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
	image_height, image_width = gray.shape

	blackhat_kernel = (
		max(15, image_width // 30),
		max(3, image_height // 30),
	)
	blackhat = cv2.morphologyEx(
		gray,
		cv2.MORPH_BLACKHAT,
		cv2.getStructuringElement(cv2.MORPH_RECT, blackhat_kernel),
	)
	gradient = cv2.Sobel(blackhat, cv2.CV_32F, 1, 0, ksize=-1)
	gradient = cv2.convertScaleAbs(gradient)
	gradient = cv2.normalize(gradient, None, 0, 255, cv2.NORM_MINMAX)
	gradient = cv2.GaussianBlur(gradient, (5, 5), 0)

	close_kernel = (
		max(15, image_width // 25),
		max(3, image_height // 20),
	)
	connected = cv2.morphologyEx(
		gradient,
		cv2.MORPH_CLOSE,
		cv2.getStructuringElement(cv2.MORPH_RECT, close_kernel),
		iterations=2,
	)
	_, binary = cv2.threshold(
		connected, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
	)
	contours, _ = cv2.findContours(
		binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
	)
	candidate_contours = [contours]

	_, dark_pixels = cv2.threshold(
		gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
	)
	dark_contours, _ = cv2.findContours(
		dark_pixels, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
	)
	candidate_contours.append(dark_contours)

	candidates = []
	image_area = image_height * image_width
	for contour_group in candidate_contours:
		for contour in contour_group:
			x, y, width, height = cv2.boundingRect(contour)
			aspect_ratio = width / max(1, height)
			if (
				not 2.0 <= aspect_ratio <= 7.0
				or width < image_width * 0.12
				or height < image_height * 0.025
				or width * height < image_area * 0.002
			):
				continue

			pad_x = int(width * 0.04)
			pad_y = int(height * 0.18)
			x1 = max(0, x - pad_x)
			y1 = max(0, y - pad_y)
			x2 = min(image_width, x + width + pad_x)
			y2 = min(image_height, y + height + pad_y)
			region = image[y1:y2, x1:x2]
			character_count = len(find_character_boxes(region))
			if 4 <= character_count <= 12:
				shape_score = max(
					0.0, 1.0 - abs(np.log(aspect_ratio / 4.0)) / np.log(3.0)
				)
				score = shape_score - 0.15 * abs(character_count - 8)
				candidates.append((score, x1, y1, x2 - x1, y2 - y1))

	if not candidates:
		return None

	_, x, y, width, height = max(candidates)
	return x, y, width, height


def find_character_boxes(plate):
	gray = cv2.cvtColor(plate, cv2.COLOR_BGR2GRAY)
	blur = cv2.GaussianBlur(gray, (3, 3), 0)
	_, binary = cv2.threshold(
		blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
	)

	plate_height, plate_width = gray.shape
	min_height = int(plate_height * 0.12)
	max_height = int(plate_height * 0.95)
	min_width = max(3, int(plate_width * 0.008))
	max_width = int(plate_width * 0.22)
	min_area = max(30, int(plate_height * plate_width * 0.0008))

	_, _, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
	boxes = []
	for x, y, width, height, area in stats[1:]:
		if (
			area >= min_area
			and min_height <= height <= max_height
			and min_width <= width <= max_width
			and 0.12 <= width / height <= 1.1
		):
			boxes.append((x, y, width, height))

	return sorted(boxes, key=lambda box: (box[1], box[0]))


def main():
	root = tk.Tk()
	root.withdraw()
	image_path = filedialog.askopenfilename(
		title="Select a vehicle license plate image",
		filetypes=[
			("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"),
			("All files", "*.*"),
		],
	)
	root.destroy()

	if not image_path:
		print("No image selected. Program stopped.")
		return

	image_bytes = np.frombuffer(Path(image_path).read_bytes(), dtype=np.uint8)
	image = cv2.imdecode(image_bytes, cv2.IMREAD_COLOR)
	if image is None:
		raise SystemExit("OpenCV could not read the selected image.")

	plate_region = find_plate_region(image)
	if plate_region is None:
		print("Could not automatically find the plate; processing the full image.")
		plate = image
	else:
		x, y, width, height = plate_region
		plate = image[y:y + height, x:x + width]
		print("License plate detected automatically.")

	boxes = find_character_boxes(plate)
	if not boxes:
		raise SystemExit(
			"No characters found. Try a clearer, less tilted plate image."
		)

	image_file = Path(image_path)
	output_dir = image_file.parent / f"{image_file.stem}_ky_tu"
	output_dir.mkdir(parents=True, exist_ok=True)
	for number, (char_x, char_y, char_width, char_height) in enumerate(
		boxes, start=1
	):
		padding = 2
		x1 = max(0, char_x - padding)
		y1 = max(0, char_y - padding)
		x2 = min(plate.shape[1], char_x + char_width + padding)
		y2 = min(plate.shape[0], char_y + char_height + padding)
		crop = plate[y1:y2, x1:x2]
		path = output_dir / f"ky_tu_{number:02d}.png"
		encoded_crop_ok, encoded_crop = cv2.imencode(".png", crop)
		if not encoded_crop_ok:
			raise SystemExit(f"Could not encode character image: {path}")
		encoded_crop.tofile(str(path))

	print(f"Saved {len(boxes)} character images to: {output_dir}")


if __name__ == "__main__":
	main()