"""Install the dependency once in a terminal:
python -m pip install opencv-python
"""

from pathlib import Path
import tkinter as tk
from tkinter import filedialog

try:
    import cv2
    import numpy as np
except ModuleNotFoundError as error:
    raise SystemExit(
        "OpenCV is missing. Run: python -m pip install opencv-python"
    ) from error


def main():
    root = tk.Tk()
    root.withdraw()
    image_path = filedialog.askopenfilename(
        title="Select an image to convert",
        filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff")],
    )
    root.destroy()

    if not image_path:
        print("No image selected. Program stopped.")
        return

    image_data = np.fromfile(image_path, dtype=np.uint8)
    image = cv2.imdecode(image_data, cv2.IMREAD_COLOR)
    if image is None:
        raise SystemExit("OpenCV could not read the selected image.")

    source_path = Path(image_path)
    output_formats = {
        ".png": "PNG",
        ".jpg": "JPEG",
        ".bmp": "BMP",
    }

    for extension, format_name in output_formats.items():
        output_path = source_path.with_name(
            f"{source_path.stem}_converted{extension}"
        )
        success, encoded_image = cv2.imencode(extension, image)
        if not success:
            raise SystemExit(f"Could not encode the image as {format_name}.")
        encoded_image.tofile(output_path)
        print(f"Saved {format_name}: {output_path}")


if __name__ == "__main__":
    main()
