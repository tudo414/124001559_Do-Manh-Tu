"""Install the dependency once in a terminal:
python -m pip install opencv-python
"""

import tkinter as tk
from tkinter import filedialog

try:
    import cv2
    import numpy as np
except ModuleNotFoundError as error:
    raise SystemExit(
        "OpenCV is missing. Run: python -m pip install opencv-python"
    ) from error


def read_image(path):
    image_data = np.fromfile(path, dtype=np.uint8)
    image = cv2.imdecode(image_data, cv2.IMREAD_COLOR)
    return image


def fit_for_display(image, max_width, max_height):
    height, width = image.shape[:2]
    scale = min(max_width / width, max_height / height, 1.0)
    if scale < 1.0:
        size = (int(width * scale), int(height * scale))
        return cv2.resize(image, size, interpolation=cv2.INTER_AREA)
    return image


def main():
    root = tk.Tk()
    root.withdraw()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    file_types = [("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff")]

    first_path = filedialog.askopenfilename(
        title="Select the first image", filetypes=file_types
    )
    if not first_path:
        root.destroy()
        print("No first image selected. Program stopped.")
        return

    second_path = filedialog.askopenfilename(
        title="Select the second image", filetypes=file_types
    )
    root.destroy()
    if not second_path:
        print("No second image selected. Program stopped.")
        return

    image1 = read_image(first_path)
    image2 = read_image(second_path)
    if image1 is None:
        raise SystemExit("Could not read the first image.")
    if image2 is None:
        raise SystemExit("Could not read the second image.")

    if image1.shape != image2.shape:
        image2 = cv2.resize(
            image2,
            (image1.shape[1], image1.shape[0]),
            interpolation=cv2.INTER_AREA,
        )

    result = cv2.bitwise_and(image1, image2)
    display_result = fit_for_display(
        result, max(1, int(screen_width * 0.9)), max(1, int(screen_height * 0.8))
    )

    window_name = "Bitwise AND Result"
    cv2.imshow(window_name, display_result)
    print("Press any key in the result window to stop.")
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
