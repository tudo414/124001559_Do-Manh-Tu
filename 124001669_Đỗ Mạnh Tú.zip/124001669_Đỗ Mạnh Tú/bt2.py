"""Install the dependency once in a terminal:
python -m pip install opencv-python
"""

import tkinter as tk
from tkinter import filedialog

try:
    import cv2
except ModuleNotFoundError as error:
    raise SystemExit(
        "OpenCV is missing. Run: python -m pip install opencv-python"
    ) from error


def fit_for_display(image, max_width, max_height):
    height, width = image.shape[:2]
    scale = min(max_width / width, max_height / height, 1.0)
    if scale < 1.0:
        size = (int(width * scale), int(height * scale))
        return cv2.resize(image, size, interpolation=cv2.INTER_AREA)
    return image


def main():
    root = tk.Tk()
    root.withdraw()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    image_path = filedialog.askopenfilename(
        title="Select a color image",
        filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff")],
    )
    root.destroy()

    if not image_path:
        print("No image selected. Program stopped.")
        return

    image_bgr = cv2.imread(image_path)
    if image_bgr is None:
        raise SystemExit("OpenCV could not read the selected image.")

    image_gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    image_hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)

    max_width = max(1, screen_width // 3 - 20)
    max_height = int(screen_height * 0.8)
    images = [
        ("Original - BGR", image_bgr),
        ("Grayscale", image_gray),
        ("HSV raw values", image_hsv),
    ]

    for index, (window_name, image) in enumerate(images):
        display_image = fit_for_display(image, max_width, max_height)
        cv2.imshow(window_name, display_image)
        cv2.moveWindow(window_name, index * (screen_width // 3), 30)

    print("Press any key in an image window, or close a window, to stop.")
    try:
        while True:
            key = cv2.waitKey(50)
            if key != -1:
                break
            try:
                if any(
                    cv2.getWindowProperty(name, cv2.WND_PROP_VISIBLE) < 1
                    for name, _ in images
                ):
                    break
            except cv2.error:
                break
    finally:
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
