"""Install the dependencies once in a terminal:
python -m pip install opencv-python Pillow
"""

import tkinter as tk
from tkinter import filedialog

try:
    import cv2
    from PIL import Image
except ModuleNotFoundError as error:
    raise SystemExit(
        "Missing dependencies. Run: python -m pip install opencv-python Pillow"
    ) from error


def main():
    root = tk.Tk()
    root.withdraw()
    max_width = int(root.winfo_screenwidth() * 0.9)
    max_height = int(root.winfo_screenheight() * 0.8)
    image_path = filedialog.askopenfilename(
        title="Select an image",
        filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff")],
    )
    root.destroy()

    if not image_path:
        print("No image selected.")
        return

    image_cv = cv2.imread(image_path)
    if image_cv is None:
        raise SystemExit("OpenCV could not read the selected image.")

    height, width = image_cv.shape[:2]
    scale = min(max_width / width, max_height / height, 1.0)
    if scale < 1.0:
        display_size = (int(width * scale), int(height * scale))
        image_cv = cv2.resize(image_cv, display_size, interpolation=cv2.INTER_AREA)

    cv2.imshow("OpenCV", image_cv)
    print("Press any key in the OpenCV window to continue to Pillow.")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    with Image.open(image_path) as image_pillow:
        image_pillow.show(title="Pillow")


if __name__ == "__main__":
    main()
