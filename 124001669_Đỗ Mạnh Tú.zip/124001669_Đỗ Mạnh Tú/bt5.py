"""Install the dependency once in a terminal:
python -m pip install opencv-python
"""

import tkinter as tk
from tkinter import filedialog

try:
    import cv2
    import numpy as np
except ModuleNotFoundError as error:
    raise SystemExit(
        "OpenCV is missing. Run: python -m pip install opencv-python"
    ) from error


BRIGHTNESS_VALUE = 50


def fit_for_display(image, max_width, max_height):
    height, width = image.shape[:2]
    scale = min(max_width / width, max_height / height, 1.0)
    if scale < 1.0:
        size = (int(width * scale), int(height * scale))
        return cv2.resize(image, size, interpolation=cv2.INTER_AREA)
    return image


def main():
    root = tk.Tk()
    root.withdraw()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    image_path = filedialog.askopenfilename(
        title="Select an image",
        filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff")],
    )
    root.destroy()

    if not image_path:
        print("No image selected. Program stopped.")
        return

    image_data = np.fromfile(image_path, dtype=np.uint8)
    original = cv2.imdecode(image_data, cv2.IMREAD_COLOR)
    if original is None:
        raise SystemExit("OpenCV could not read the selected image.")

    brightness = np.full(original.shape, BRIGHTNESS_VALUE, dtype=np.uint8)
    brighter = cv2.add(original, brightness)

    max_width = max(1, screen_width // 2 - 20)
    max_height = max(1, int(screen_height * 0.8))
    windows = [
        ("Original", original),
        (f"Brighter (+{BRIGHTNESS_VALUE})", brighter),
    ]

    for index, (window_name, image) in enumerate(windows):
        display_image = fit_for_display(image, max_width, max_height)
        cv2.imshow(window_name, display_image)
        cv2.moveWindow(window_name, index * (screen_width // 2), 30)

    print("Press any key in an image window to stop.")
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
